# Saorin_Faura-Angel_Luis-48616905B_TareaFinal\ModaNova\database\db_setup.py

from db_connection import ConexionDB
import sqlite3

class DBSetup:
    def __init__(self, ruta_bd="database/modanova.db"):
        """
        Inicializa la configuración de la base de datos.
        :param ruta_bd: Ruta al archivo de la base de datos SQLite.
        """
        self.ruta_bd = ruta_bd

    def crear_tablas(self):
        """
        Crea las tablas necesarias para la base de datos de ModaNova.
        """
        with ConexionDB(self.ruta_bd) as conexion:
            cursor = conexion.cursor()
            try:
                # Tabla Roles
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS Rol (
                        id_rol INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre_rol TEXT NOT NULL UNIQUE
                    );
                """)

                # Tabla Usuarios
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS Usuario (
                        id_usuario INTEGER PRIMARY KEY AUTOINCREMENT,
                        email TEXT NOT NULL UNIQUE,
                        contrasena TEXT NOT NULL,
                        id_rol INTEGER NOT NULL,
                        id_cliente INTEGER,
                        id_trabajador INTEGER,
                        FOREIGN KEY (id_rol) REFERENCES Rol(id_rol),
                        FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente),
                        FOREIGN KEY (id_trabajador) REFERENCES Trabajador(id_trabajador)
                    );
                """)

                # Tabla Cliente
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS Cliente (
                        id_cliente INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre_cliente TEXT NOT NULL,
                        telefono TEXT,
                        direccion TEXT,
                        fecha_registro DATE DEFAULT CURRENT_DATE
                    );
                """)

                # Tabla Trabajador
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS Trabajador (
                        id_trabajador INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre_trabajador TEXT NOT NULL,
                        telefono TEXT,
                        email TEXT UNIQUE NOT NULL,
                        puesto TEXT NOT NULL,
                        salario REAL
                    );
                """)

                # Tabla Proveedor
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS Proveedor (
                        id_proveedor INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre_proveedor TEXT NOT NULL,
                        contacto TEXT,
                        telefono TEXT NOT NULL,
                        correo TEXT UNIQUE NOT NULL
                    );
                """)

                # Tabla Producto
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS Producto (
                        id_producto INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre_producto TEXT NOT NULL,
                        descripcion TEXT,
                        precio REAL NOT NULL,
                        stock INTEGER NOT NULL,
                        id_proveedor INTEGER,
                        FOREIGN KEY (id_proveedor) REFERENCES Proveedor(id_proveedor)
                    );
                """)

                # Tabla Venta
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS Venta (
                        id_venta INTEGER PRIMARY KEY AUTOINCREMENT,
                        fecha DATE DEFAULT CURRENT_DATE,
                        id_cliente INTEGER NOT NULL,
                        total REAL NOT NULL,
                        FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente)
                    );
                """)

                # Tabla intermedia VentaProducto
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS VentaProducto (
                        id_venta_producto INTEGER PRIMARY KEY AUTOINCREMENT,
                        id_venta INTEGER NOT NULL,
                        id_producto INTEGER NOT NULL,
                        cantidad INTEGER NOT NULL,
                        precio_unitario REAL NOT NULL,
                        FOREIGN KEY (id_venta) REFERENCES Venta(id_venta),
                        FOREIGN KEY (id_producto) REFERENCES Producto(id_producto)
                    );
                """)

                # Datos iniciales para Roles
                cursor.execute("INSERT OR IGNORE INTO Rol (id_rol, nombre) VALUES (1, 'cliente');")
                cursor.execute("INSERT OR IGNORE INTO Rol (id_rol, nombre) VALUES (2, 'trabajador');")

                conexion.commit()
                print("Tablas creadas exitosamente y datos iniciales añadidos.")
            except sqlite3.Error as e:
                print(f"Error al crear las tablas: {e}")
                conexion.rollback()
