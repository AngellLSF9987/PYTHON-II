from database.db_setup import DBSetup

def main():
    """
    Punto de entrada principal del programa.
    """
    print("Iniciando el sistema ModaNova...")
    
    # Configuración inicial de la base de datos
    print("Configurando la base de datos...")
    db_setup = DBSetup()
    db_setup.crear_tablas()
    
    # Aquí puedes agregar el código para iniciar el backend o más funcionalidades
    print("¡El sistema está listo para usarse!")

if __name__ == "__main__":
    main()
