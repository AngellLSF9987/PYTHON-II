class EstucheLlenoError(Exception):
    pass

class Estuche:
    def __init__(self, capacidad):
        self.capacidad = capacidad
        self.boligrafos = []

    def agregar_boligrafo(self,boli):
        if len(self.boligrafos) < self.capacidad:
            self.boligrafos.append(boli)
        else:
            raise EstucheLlenoError("El estuche está lleno")

    def quitar_boligrafo(self, indice):
            boligrafo = self.boligrafos.pop(indice)
            return boligrafo



mi_estuche = Estuche(5)
try:
    mi_estuche.agregar_boligrafo("Azul")
    mi_estuche.agregar_boligrafo("Negro")
    mi_estuche.agregar_boligrafo("Rojo")
    mi_estuche.agregar_boligrafo("Verde")
    mi_estuche.agregar_boligrafo("Violeta")
    mi_estuche.agregar_boligrafo("Gris")
except EstucheLlenoError as e:
    print(e)

try:
    boligrafo = mi_estuche.quitar_boligrafo(1)
    print("Quité un bolígrafo:", boligrafo)
except IndexError as e:
    print(e)