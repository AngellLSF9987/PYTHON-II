"""▰ Ejercicio 4:
▻ Crea un programa que pida al usuario su edad y verifique que sea un
número válido y mayor que 0.
"""
class ErrorEdadNegativa(Exception):
    
    def __init__(self, mensaje,funcion,lineaCodigo):
        super().__init__(mensaje)
        self.mensaje = mensaje
        self.funcion = funcion
        self.lineaCodigo = lineaCodigo
        

    def info(self):
        return f"Error: {self.mensaje}, funcion: {self.funcion} y linea de codigo: {self.lineaCodigo}"
    
class MiError(Exception):
    pass


def validar_edad():
    try:
        edad = int(input("Introduce tu edad: "))
        if edad <= 0:
            raise MiError("La edad no puede ser negativa ni 0")
    except ValueError as e:
        print(f"Error: {e}")
    except ErrorEdadNegativa as e:
        print(e.info())
    except MiError as e:
        print(f"Error: {e}")
    else:
        print(f"La edad es {edad}")
        
validar_edad()