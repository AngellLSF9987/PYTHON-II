"""Ejercicio 5:
▻ Escribe un programa que calcule la raíz cuadrada de un número
ingresado por el usuario. Maneja la excepción si el número es
negativo.
"""

import math

class ErrorNumerosNegativos(Exception):
    pass

def raiz_cuadrada():
    try:
        numero = float(input("Introduce un numero positivo: "))
        if numero < 0:
            raise ErrorNumerosNegativos("No se puede meter valores negativos")
        resultado = math.sqrt(numero)
        print(resultado)
    except ValueError:
        print("Error: Debes introducir un numero")
    except ErrorNumerosNegativos as e:
        print(f"Error: {e}")
        
# raiz_cuadrada()



    
        
    