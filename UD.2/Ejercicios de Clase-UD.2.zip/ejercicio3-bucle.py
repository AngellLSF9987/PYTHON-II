"""Ejercicio 3:
▻ Crea un programa que pida al usuario ingresar números y calcule su
suma. Termina el bucle cuando el usuario ingresa "fin". Maneja la
excepción para entradas no numéricas."""

#Version - Fernanda
def suma_numeros():
    suma = 0
    while True:
        x = input("Introduce un numero o fin para terminar: ")
        if x == "fin":
            break
        try:
            numero = float(x)
            suma += numero
        except ValueError:
            print("Error: Ingresa un numero o fin")
        except Exception as e:
            print(type(e).__name__)
        except:
            print("Error")

    print(f"La suma total es {suma}")
    
suma_numeros()



#Version 2 - David 1

suma = 0
while True:
    num2 = input("Introduce un numero o fin para terminar: ")
    if num2 == "fin":
        break
    else:
        try:
            num2 = float(num2)
            suma = suma+num2
            print(suma)
        except ValueError:
            print("Introduce un valor correcto")