"""Ejercicio 1:
▻ Escribe un programa que pida al usuario un número entero y lo
convierta a un tipo entero. Maneja las excepciones si el usuario
ingresa un valor no numérico. (No hacer casting en el input"""

#Version 1
def convertir_a_entero():
    try:
        numero = input("Introduce un numero entero: ")
        entero = int(numero)
    except ValueError:
        print("Error: Debe ingresar un número entero válido")
    except:
        print("Error")
    else:
        print(f"El numero entero es {entero}")
    
# convertir_a_entero()
        
#Version 2 - Kike

def es_entero(cadena):
    try:
        int(cadena)
        return True
    except ValueError:
        return False
      
cadena = input("Introduzca un numero entero: ")
if es_entero(cadena):print(int(cadena))
else: print("No es un entero")

#Version 2 - David 1

while True:
    num = input("Introduzca un numero entero, por favor :) : ")
    try:
        int(num)
        print(f"Su numero es: {num}")
    except ValueError:
        print(f"Te he pedido por favor que introduzcas un número entero \" {num} \"")
    except Exception as e:  
        print(type(e).__name__) 
    else:
        break
    


    