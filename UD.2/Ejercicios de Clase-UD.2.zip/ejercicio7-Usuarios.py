"""Ejercicio 7:
▻ Crea un programa que simule un registro de usuarios. Pide al usuario
un nombre de usuario y asegúrate de que no esté vacío.
"""

def crear_usuario():
    try:
        nombre = input("Introduce tu nombre: ")
        if not nombre:
            raise ValueError("El nombre no puede ir vacio")
    except ValueError as e:
        print(f"Error: {e}")
    else:
        print("Registro completado")
        

crear_usuario()
    
    