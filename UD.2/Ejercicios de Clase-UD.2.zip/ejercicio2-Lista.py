#Version - Loreto

def indice_lista():
    #Se puede hacer igual con tuplas
    nombres = ("Teo","Pablo","Kike","Paco")

    try:
        indice = int(input("Introduce un numero entero entre 0 y 3: "))
        nombre = nombres[indice]
    except ValueError:
        print("Debe introducir un numero entero")
    except IndexError:
        print("Debe introducir un numero dentro del rango")
    else:
        print(f"El nombre es {nombre}")
        
indice_lista()

#Version 2 - Kaloyan
#Con listas
nombres = ["Teo","Pablo","Kike","Paco"]
try:
    indice = int(input("Introduce un numero entero entre 0 y 3: "))
    print("Nombre del indice: ",indice,"es: ",nombres[indice])
except IndexError:
    print("Estas fuera de rango")
except ValueError:
    print("Error: Debes introducir un numero")


#Version 3 - Carlos

