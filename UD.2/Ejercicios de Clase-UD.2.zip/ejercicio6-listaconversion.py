"""Ejercicio 6:
▻ Escribe un programa que intente convertir todos los elementos de una
lista a enteros. Maneja las excepciones para cada conversión
individual.
"""
def convertir_lista():
    lista = ["30","20","20",20,15,"Hola"]
    enteros = []
    
    for elemento in lista:
        if type(elemento) == int or elemento.isdigit():
            print(elemento)
             

convertir_lista()