def validar_datos_float(num):
    numero = float(num)
    return numero
    
def division_segura():
    try:
        num1 = int(input("Introduce un numero entero: "))
        num2 = input("Introduce un numero: ")
        num1 = validar_datos_float(num1)
        num2 = validar_datos_float(num2)
        division = num1/num2
        print(division)

    except ZeroDivisionError:
        print("Error: El divisor no puede ser 0")
    except ValueError:
        print("Error: No se puede convertir en float")
    else:
        print("Todo ha ido correcto")
    finally:
        print("Se ha ejecutado el programa")


division_segura()