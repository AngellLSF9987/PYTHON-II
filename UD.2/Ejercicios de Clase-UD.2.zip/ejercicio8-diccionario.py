"""Ejercicio 8:
▻ Crea un programa que permita al usuario buscar un valor en un
diccionario utilizando una clave. Maneja la excepción si la clave no
existe."""

diccionario = {"libro":"rojo","carpeta":"azul","raton":"negro"}
clave = input("Introduce una clave")

try:
    valor = diccionario[clave]
except KeyError:
    print(f"Error: No existe {clave}")
else:
    print(f"El valor asociado a {clave} es {valor}")
    