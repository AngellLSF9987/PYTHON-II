class Animal:
    def __init__(self,nombre,peso,edad):
        self.nombre = nombre
        self.peso = peso
        self.edad = edad
    
    def sonidos(self):
        print(f"{self.nombre} hace ",end="")
    
class Gato(Animal):
    
    def __init__(self, nombre, peso, edad,vidas):
        super().__init__(nombre, peso, edad)
        self.vidas = vidas
        
    def sonidos(self):
        super().sonidos()
        print("Miau")
        
class Perro(Animal):
    
    def __init__(self, nombre, peso, edad,raza):
        super().__init__(nombre, peso, edad)
        self.raza = raza
        
    def sonidos(self):
        super().sonidos()
        print("Guau")
        
Billy = Gato("Billy", 3,8,3)
Billy.sonidos()
print(Billy.edad)

Alma = Perro("Alma",35,9,"Golden Retriever")
Alma.sonidos()