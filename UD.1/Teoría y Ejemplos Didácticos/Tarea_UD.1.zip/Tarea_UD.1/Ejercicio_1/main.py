from utilidades.menu import menu

if __name__ == "__main__":
    menu()