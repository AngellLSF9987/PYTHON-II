# examen30_Ej47modelos/pincel.py

class Pincel:
    
    def usar(self):
        print("Pincel en uso: Alisando la superficie de la uña...")