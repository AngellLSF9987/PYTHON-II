# examen30_Ej47modelos/lima.py

class Lima:
    def usar(self):
        print("Lima en uso: Limando la uña...")